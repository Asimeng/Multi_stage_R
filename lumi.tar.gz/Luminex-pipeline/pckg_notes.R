
library(devtools)

# use_build_ignore(c("pckg_notes.R", "flow.Rmd", "Rproj"))

# use_description(check_name = FALSE)

# use_package("purrr", "Imports")

# DESCRIPTION edited manually with other packages

document()

# Analyte reference
# created in analyte_ref_make.R
# raw tables used by analyte_ref_make is in ist/extdata/analyte_ref_raw
# raw tables created in mbhgAnalyteList_make.R and symbol_codes_make.R
# analyte reference table used by pipeline is in data/ as .RData file

# add analyte_ref.RData to data/ folder, available to user
# add tables that analyte_ref come from as raw data to inst/extdata



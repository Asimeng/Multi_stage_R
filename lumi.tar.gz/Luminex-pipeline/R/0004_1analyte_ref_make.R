
# Should move this out of package

# this makes a test analyte_reference, as it is not currently available 

analyte_ref_make <- function(dta = dta){
  # x <- unique(dta$analyte)
  x <- unique(dta$analyte)
  x <- str_split_fixed(x, "\\(", 2)
  x <- x[,1]
  x1 <- x

  x <- gsub("  *$", "", x, perl = TRUE) # or gsub("\\s+$", "", x, perl = TRUE)
  x <- gsub("\\s+$", "", x, perl = TRUE)
  x <- gsub("\\s+", "_", x, perl = TRUE)
  x <- gsub("\\/", "_", x, perl = TRUE)
  x <- gsub("\\-", "", x, perl = TRUE)
  
 
  analyte_reference <- tibble(analyte = x1,
                              analyte_new = x)
  assign("analyte_reference", analyte_reference, envir = .GlobalEnv)
}

# analyte_reference %>% 
#   print(n = Inf)




#' Import Luminex text files
#'
#' @param dir_data Path to the directory containing Luminex .txt files. dir_data can contain subfolders.
#'
#' @return
#' @export
#'
#' @examples
data_import <- function(dir_data) {
  
  files <- list.files(dir_data, recursive = TRUE,
                      full.names = TRUE)
  
  luminex_list <- list()
  
  files_invalid <- tibble::tibble(
    files = files,
    txt = NA,
    line_first = NA,
    header_repeat = NA
  )
  
  names_check <-
    c("Analyte",
      "Type",
      "Well",
      "Outlier",
      "Description",
      "FI",
      "FI...Bkgd")
  
  for (i in 1:length(files)) {
    
    if(grepl(".txt", files[i]) == FALSE){
      
        files_invalid$line_first[i] <- 0
        files_invalid$header_repeat[i] <- 0
        files_invalid$txt[i] <- 0
        
    } else if(grepl(".txt", files[i]) == TRUE){ #opens1
      
    plate <-
      read.delim(files[i], 
                 stringsAsFactors = FALSE,
                 strip.white = TRUE)
    
    if(ncol(plate) > 2){ #opens2
    
    if(!is.null(names(plate))){
    line_first <- unlist(names(plate))  
    }
    
    files_invalid$line_first[i] <-
      sum(names_check %in% line_first) == length(names_check)
    
    
    x <- grep("Analyte", plate[, 1])
    x1 <- grep("Well", plate[,3])
    if(length(x) != 0 & length(x1) != 0){
    files_invalid$header_repeat[i] <- x == x1
    }
    } else{
      files_invalid$line_first[i] <- 0
      files_invalid$header_repeat[i] <- 0
      files_invalid$txt[i] <- 1
    }
    # closes2
    
    files_invalid$txt[i] <- grepl(".txt", files[i])
    
    
    x2 <- sum(files_invalid$line_first[i],
             files_invalid$header_repeat[i],
             files_invalid$txt[i])
    
    if(is.null(x2) | is.na(x2)){
      luminex_list[[i]] <- "invalid"
      
    } else if (x2 == 3) {
      plate <- plate[(x + 1):nrow(plate), ]
      
      plate$filename <-
        sub("\\..*$", "", sub("^.*[/\\]", "", files[i]))
      # remove path and extension from filename
      
      luminex_list[[i]] <- plate
    } else{
      luminex_list[[i]] <- "invalid"
    }
    } #closes1
  }
  
  files <- dplyr::filter(files_invalid,
                         txt == TRUE &
                           line_first == TRUE &
                           header_repeat == TRUE) %>%
    dplyr::pull(files)
  readr::write_rds(files, "rds/rep_files.rds")
  files_invalid <- dplyr::filter(files_invalid,
                                 txt == FALSE |
                                   line_first == FALSE |
                                   header_repeat == FALSE)
  readr::write_rds(files_invalid, "rds/rep_files_invalid.rds")
  
  luminex_list <- luminex_list[luminex_list != "invalid"]
  dta <- dplyr::bind_rows(luminex_list)
  readr::write_rds(dta, "rds/dta.rds")
}


# not exported -------------------

filename_separate1 <- function(data = d) {

  rr <- tibble::tibble(
    filename = unique(data$filename),
    filename_new = tolower(filename),
    kit = NA,
    instrument = NA,
    date = NA,
    plate1 = NA,
    plate = NA,
    rerun = NA
  )
  
  rr$filename_new <- gsub("\\.|\\/|\\-", "_", rr$filename_new)
  rr$filename_new <- gsub("\\_+", "_", rr$filename_new)
  rr$filename_new <- gsub("\\_$|^\\_", "", rr$filename_new)
  
  # Kit
  rr$kit <- gsub("([a-z0-9&]+)_([a-z]+)_([0-9]+)_(.*)",
                 "\\1",
                 rr$filename_new)
  
  # Instrument
  rr$instrument <- gsub("([a-z0-9&]+)_([a-z]+)_([0-9]+)_(.*)",
                        "\\2",
                        rr$filename_new)
  
  # Date
  rr$date <- gsub("(.*)_([[:alnum:]]*20[0-9][0-9][[:alnum:]]*)_(.*)",
                  "\\2",
                  rr$filename_new)
  
  # Plate nr
  rr$plate1 <- gsub("([a-z0-9&]+)_([a-z]+)_([0-9]+)_(.*)",
                    "\\4",
                    rr$filename_new)
  
  ######

  
  r <- rr$plate1
  
  r <- gsub("([a-z]+)", "_", r)
  
  r <- gsub("(^[[:punct:]]*)", "", r)
  
  r <- gsub("[_]+[0-9]+|[_]*", "", r)
  
  r <- ifelse(grepl("^[a-z]*$",
                    rr$plate1, perl = TRUE) == TRUE,
              NA, r)
  
  r <- gsub("(*)\\s+([0-9]+)", "\\1", r)
  
  r <- gsub("\\s+", "", r)
  
  rr$plate <- ifelse(is.na(r),
                     1, r)
  
  # rerun
  r <- rr$plate1
  
  r <- gsub("^[0-9]+$", NA, r)
  
  r <- gsub("^[0-9]+", "", r)
  
  r <- gsub('rerun|r', "", r)
  
  r <- gsubfn::gsubfn("\\w+",
                      setNames(as.list(1:100),
                               tolower(english::as.english(1:100))), r)
  r[r %in% c("NA", "na")] <- NA
  
  r <- gsub("[0-9]*[_]", "", r)
  
  r <- gsub("\\s+", "", r)
  
  rr$rerun <- r
  
  rr$rerun <- ifelse(rr$rerun == "", 1, rr$rerun)
  
  rr$rerun <- ifelse(is.na(rr$rerun) == TRUE, 0, rr$rerun)
  
  ######

  dta <-  rr %>% 
    select(filename, date, kit, instrument, plate, rerun) %>% 
    inner_join(data)  %>% 
    distinct()
  
    
}


instrument_name_check <- function(d, instrument_names) {
  #' Check whether instrument_name is same as input instrument_name.
  #' @param d dataframe created by preceding function
  #' @param instrument_names character vector from essential metadata
  #' @description
  #' @return
  
  
  a <- which(!d$instrument %in% instrument_names)
  
  if (length(a) != 0 & length(a) != nrow(d)) {
    tmp <- tibble::tibble(instrument_names_unexpected = d$instrument[a],
                  in_filename = d$filename[a])
    readr::write_rds(tmp, "rds/rep_instr_unexpected.rds")
  }
  
  if (length(a) == nrow(d)) {
    tmp <- tibble::tibble(unexpected_instrument_names = unique(d$instrument))
    readr::write_rds(tmp, "rds/rep_instr_unexpected.rds")
  }
  
  if (sum(!d$instrument %in% instrument_names) == 0) {
    tmp <- tibble::tibble(instrument_names_unexpected = NA)
    readr::write_rds(tmp, "rds/rep_instr_unexpected.rds")
  }
}


# NOT exported
# check date format ----------------------------

dates_filename <- function(d) {
  #' Check date format in FileName
  #' @param d Dataset created by preceding function
  #' @description
  #' @return
  
  
  dd <- lubridate::parse_date_time(d$date, orders = c("ymd", "dmy", "mdy"), train = TRUE)
  
  # If output created, check for NAs
  # If no NAs, print unique dates
  # If NAs, print the ones that produced NAs
  # If no output created or error - message
  
  if(exists("dd") == FALSE){
    dates_info <- "No dates could be parsed"
  } else if(sum(is.na(dd)) == length(d$Date) | is.null(dd) == TRUE){
    dates_info <- "No dates could be parsed"
  } else if(sum(is.na(dd)) != 0 & sum(is.na(dd) != length(d$Date))){
    dates_info <- list(unique(dd), d$Date[is.na(dd)])
    names(dates_info) <- c("Correctly_parsed_unique_ dates", "Incorrectly_parsed_dates")
  } else if(sum(is.na(dd)) == 0){
    dates_info <- list(Correctly_parsed_unique_dates = unique(dd))
    d$Date <- dd
    readr::write_rds(dates_info, "rds/rep_dates_info.rds")
    assign("d", d, envir = .GlobalEnv)
  }
}

# Exported -----------------------------------

#' Filename separation
#' Check structure of observations in the filename column in the imported data.
#' @param data Dataframe produced by data_import
#' @param instrument_names Character vector of expected instrument names
#' @return
#' @export
#'
#' @examples
filename_separate <- function(data = dta,
                              instrument_names = instrument_names){
  
  d <- data
  # 1. separate filename
  
  d <- filename_separate1(data = d)
  
  
  # 2. check instrument names
  
  instrument_name_check(d, instrument_names)
  
  # 2.  check date format
  
  dates_filename(d)
  
  readr::write_rds(d, "rds/dta.rds")
  
  }










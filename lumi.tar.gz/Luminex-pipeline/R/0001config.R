
# my solution for now... I know it is bad manners to make changes to other people's globEnv and folders

pipeline_config <- function(wd, dd, md = NA,
                            aref, isa_path = NULL,
                            config_isa = FALSE,
                            tech_reps){
  
  #' @param wd Path to working directory, character string
  #' @param dd Path to input data directory, character string
  #' @param md Path to directory containing md5sums, character string
  #' @description Saves paths to directories as objects to use 
  #' throughout or change as necessary.  Creates rds folder to save rds objects in.
  
  assign("dir_main", wd, envir = .GlobalEnv)
  assign("dir_data", dd, envir = .GlobalEnv)
  assign("dir_md5sum", md, envir = .GlobalEnv)
  assign("analyte_reference_path", aref, envir = .GlobalEnv)
  assign("isa_path", isa_path, envir = .GlobalEnv)
  assign("config_isa", config_isa, envir = .GlobalEnv)
  assign("tech_reps", tech_reps, envir = .GlobalEnv)
  
  dir.create(file.path(dir_main, "rds"))
}






# ?Shouldn't be writing a rds necessarily as it is such a short step

#' Clean column names
#'
#' @param dta 
#'
#' @return
#' @export
#'
#' @examples
colnames_clean <- function(dta){

  colnames(dta) <- tolower(colnames(dta))
  colnames(dta) <- gsub("\\.\\.+", "\\.", colnames(dta), perl = TRUE)
  colnames(dta) <- gsub("\\.", "\\_", colnames(dta), perl = TRUE)
  colnames(dta) <- gsub("\\.$", "", colnames(dta), perl = TRUE)
  colnames(dta) <- gsub("^\\s", "\\1", colnames(dta), perl = TRUE)
  colnames(dta) <- gsub("\\s$", "\\1", colnames(dta), perl = TRUE)
  
  readr::write_rds(dta, "rds/dta.rds")
  # assign("dta", dta, envir = .GlobalEnv)

}